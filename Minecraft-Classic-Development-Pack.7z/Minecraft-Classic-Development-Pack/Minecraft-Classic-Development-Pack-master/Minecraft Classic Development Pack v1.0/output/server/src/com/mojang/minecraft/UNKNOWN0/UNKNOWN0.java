package com.mojang.minecraft.UNKNOWN0;


public interface UNKNOWN0 {
}
