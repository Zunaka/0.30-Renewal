package com.mojang.minecraft.server;

import com.mojang.net.NetworkHandler;

public final class UNKNOWN0 {

   public NetworkHandler networkHandler;
   public int b;


   public UNKNOWN0(NetworkHandler var1, int var2) {
      this.networkHandler = var1;
      this.b = 100;
   }
}
