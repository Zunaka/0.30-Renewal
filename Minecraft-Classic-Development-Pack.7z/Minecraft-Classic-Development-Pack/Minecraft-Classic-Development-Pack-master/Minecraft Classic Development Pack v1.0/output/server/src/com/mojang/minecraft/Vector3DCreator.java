package com.mojang.minecraft;

import com.mojang.minecraft.model.Vector3D;

public final class Vector3DCreator {

   public Vector3DCreator(int var1, int var2, int var3, int var4, Vector3D var5) {
      new Vector3D(var5.x, var5.y, var5.z);
   }
}
