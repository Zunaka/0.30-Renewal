package com.mojang.minecraft.render;


public interface UNKNOWN0 {
}
