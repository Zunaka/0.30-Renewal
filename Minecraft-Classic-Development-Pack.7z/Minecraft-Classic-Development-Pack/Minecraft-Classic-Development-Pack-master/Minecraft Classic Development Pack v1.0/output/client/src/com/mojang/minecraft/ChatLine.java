package com.mojang.minecraft;


public final class ChatLine {

   public String message;
   public int time;


   public ChatLine(String var1) {
      this.message = var1;
      this.time = 0;
   }
}
