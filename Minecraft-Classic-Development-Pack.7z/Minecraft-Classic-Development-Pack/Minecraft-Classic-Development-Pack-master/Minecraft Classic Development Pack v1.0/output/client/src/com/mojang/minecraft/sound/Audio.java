package com.mojang.minecraft.sound;


public interface Audio {

   boolean play(int[] var1, int[] var2, int var3);
}
