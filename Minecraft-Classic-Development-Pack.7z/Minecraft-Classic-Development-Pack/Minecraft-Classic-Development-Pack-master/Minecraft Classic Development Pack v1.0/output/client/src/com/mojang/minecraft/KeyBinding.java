package com.mojang.minecraft;


public final class KeyBinding {

   public String name;
   public int key;


   public KeyBinding(String var1, int var2) {
      this.name = var1;
      this.key = var2;
   }
}
