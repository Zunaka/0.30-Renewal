package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.Block;

public final class DirtBlock extends Block {

   protected DirtBlock(int var1, int var2) {
      super(3, 2);
   }
}
