package com.mojang.minecraft.level;


// $FF: synthetic class
final class SyntheticClass {
}
