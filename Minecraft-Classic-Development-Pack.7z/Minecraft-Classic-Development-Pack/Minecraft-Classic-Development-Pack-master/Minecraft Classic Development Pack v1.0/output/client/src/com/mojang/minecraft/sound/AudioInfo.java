package com.mojang.minecraft.sound;


public class AudioInfo {

   public float volume = 1.0F;


   public int update(short[] var1, int var2) {
      return 0;
   }
}
