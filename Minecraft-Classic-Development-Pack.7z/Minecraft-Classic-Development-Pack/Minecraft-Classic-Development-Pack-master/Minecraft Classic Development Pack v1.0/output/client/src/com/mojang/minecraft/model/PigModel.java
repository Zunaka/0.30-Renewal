package com.mojang.minecraft.model;

import com.mojang.minecraft.model.AnimalModel;

public final class PigModel extends AnimalModel {

   public PigModel() {
      super(6, 0.0F);
   }
}
