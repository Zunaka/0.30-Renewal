package com.mojang.minecraft.sound;


public interface SoundPos {

   float getRotationDiff();

   float getDistanceSq();
}
