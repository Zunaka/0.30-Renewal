package de.jarnbjo.ogg;

import java.io.IOException;

public class EndOfOggStreamException extends IOException {

   private static final long serialVersionUID = 1L;


}
