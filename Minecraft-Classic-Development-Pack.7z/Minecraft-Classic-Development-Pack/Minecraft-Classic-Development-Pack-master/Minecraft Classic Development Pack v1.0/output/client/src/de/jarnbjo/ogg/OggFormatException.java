package de.jarnbjo.ogg;

import java.io.IOException;

public class OggFormatException extends IOException {

   private static final long serialVersionUID = 1L;


   public OggFormatException() {}

   public OggFormatException(String var1) {
      super(var1);
   }
}
