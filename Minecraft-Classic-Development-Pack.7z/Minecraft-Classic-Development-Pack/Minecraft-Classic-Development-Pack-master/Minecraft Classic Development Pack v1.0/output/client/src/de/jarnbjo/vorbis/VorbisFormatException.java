package de.jarnbjo.vorbis;

import java.io.IOException;

public class VorbisFormatException extends IOException {

   private static final long serialVersionUID = 1L;


   public VorbisFormatException() {}

   public VorbisFormatException(String var1) {
      super(var1);
   }
}
